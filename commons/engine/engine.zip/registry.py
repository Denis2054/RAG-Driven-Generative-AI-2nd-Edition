# FILE: registry.py (Chapter 5 Integration - Oracle Converged Edition)
# Copyright 2026, Denis Rothman

# === Imports ===
import logging
# Import Standard LLM Agents (No Database Dependency)
from agents import agent_writer, agent_summarizer 

# Import Enterprise Oracle Agents (Chapter 4)
import agent_archivist 
import agent_recruiter

# === 5. The Agent Registry (Universal Edition) ===
class AgentRegistry:
    def __init__(self):
        self.registry = {
            # --- Standard LLM Agents ---
            "Writer": agent_writer,
            "Summarizer": agent_summarizer,
            
            # --- Enterprise Oracle Agents ---
            "OracleArchivist": agent_archivist.agent_oracle_archivist,
            "OracleRecruiter": agent_recruiter.agent_oracle_recruiter,
        }

    def get_handler(self, agent_name, client, generation_model, embedding_model):
        """
        Retrieves the appropriate agent function and curries it with the necessary infrastructure clients.
        Note: Pinecone 'index' and 'namespaces' have been removed.
        """
        handler_func = self.registry.get(agent_name)
        if not handler_func:
            logging.error(f"Agent '{agent_name}' not found in registry.")
            raise ValueError(f"Agent '{agent_name}' not found in registry.")

        # --- Handler Mapping Logic ---
        
        # 1. Writer & Summarizer (LLM Only)
        if agent_name == "Writer" or agent_name == "Summarizer":
            return lambda mcp_message: handler_func(
                mcp_message, 
                client=client, 
                generation_model=generation_model
            )
            
        # 2. OracleArchivist (Oracle Knowledge Store - Vector)
        elif agent_name == "OracleArchivist":
            return lambda mcp_message: handler_func(
                mcp_message, 
                client=client, 
                embedding_model=embedding_model
            )
            
        # 3. OracleRecruiter (Oracle Candidate Pool - Hybrid)
        elif agent_name == "OracleRecruiter":
            return lambda mcp_message: handler_func(
                mcp_message, 
                client=client, 
                embedding_model=embedding_model
            )

        else:
            raise ValueError(f"Configuration missing for agent: {agent_name}")

    def get_capabilities_description(self):
        """
        Returns a detailed description of available agents and their inputs.
        Used by the Planner (LLM) to generate execution plans.
        """
        return """
AVAILABLE CAPABILITIES:
-----------------------
1. Writer
   - Role: Generates final content by applying a Blueprint to Facts.
   - Input: {"blueprint": "string context", "facts": "string evidence", "previous_content": "optional string"}

2. Summarizer
   - Role: Reduces large text blocks to concise summaries.
   - Input: {"text_to_summarize": "string", "summary_objective": "string goal"}

3. OracleArchivist
   - Role: Retrieves unstructured documents (logs, reports) from the Oracle Database.
   - Input: {"intent_query": "string search query"}

4. OracleRecruiter
   - Role: Retrieves job candidates from Oracle Database using Hybrid Search (Structured + Semantic).
   - Input: {
       "intent_query": "string (e.g., 'Python Developer')", 
       "constraints": {"max_salary": integer, "min_experience": integer}
     }
"""

    def list_agents(self):
        """Alias for capabilities description, useful for UI display."""
        return self.get_capabilities_description()

# Initialize the global toolkit.
AGENT_TOOLKIT = AgentRegistry()
logging.info("Agent Registry initialized with Oracle Enterprise capabilities.")