# 3.Helper Functions (LLM, Embeddings, and MCP)

# === Imports ===
import logging
import json
import time
import tiktoken
import re
import copy
from tenacity import retry, stop_after_attempt, wait_random_exponential
from openai import APIError

# === Configure Production-Level Logging ===
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

# === LLM Interaction ===
@retry(wait=wait_random_exponential(min=1, max=60), stop=stop_after_attempt(6))
def call_llm_robust(system_prompt, user_prompt, client, generation_model, json_mode=False):
    """A centralized function to handle all LLM interactions with retries."""
    logging.info("Attempting to call LLM...")
    try:
        response_format = {"type": "json_object"} if json_mode else {"type": "text"}
        response = client.chat.completions.create(
            model=generation_model,
            response_format=response_format,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
        )
        logging.info("LLM call successful.")
        return response.choices[0].message.content.strip()
    except APIError as e:
        logging.error(f"OpenAI API Error in call_llm_robust: {e}")
        raise e
    except Exception as e:
        logging.error(f"An unexpected error occurred in call_llm_robust: {e}")
        raise e

# === Embeddings ===
@retry(wait=wait_random_exponential(min=1, max=60), stop=stop_after_attempt(6))
def get_embedding(text, client, embedding_model):
    """Generates embeddings for a single text query with retries."""
    text = text.replace("\n", " ")
    try:
        response = client.embeddings.create(input=[text], model=embedding_model)
        return response.data[0].embedding
    except APIError as e:
        logging.error(f"OpenAI API Error in get_embedding: {e}")
        raise e
    except Exception as e:
        logging.error(f"An unexpected error occurred in get_embedding: {e}")
        raise e

# === Model Context Protocol (MCP) ===
def create_mcp_message(sender, content, metadata=None):
    """Creates a standardized MCP message."""
    return {
        "protocol_version": "2.0 (Context Engine)",
        "sender": sender,
        "content": content,
        "metadata": metadata or {}
    }

# [FIX] Removed query_pinecone function entirely

# === Context Management Utility ===
def count_tokens(text, model="gpt-5"):
    """Counts the number of tokens in a text string."""
    try:
        encoding = tiktoken.encoding_for_model(model)
    except KeyError:
        encoding = tiktoken.get_encoding("cl100k_base")
    return len(encoding.encode(text))

# === Security Utility ===
def helper_sanitize_input(text):
    """Detects and flags potential prompt injection patterns."""
    injection_patterns = [
        r"ignore previous instructions",
        r"ignore all prior commands",
        r"you are now in.*mode",
        r"act as",
        r"ignore any legal advice",
        r"print your instructions",
        r"sudo|apt-get|yum|pip install"
    ]
    
    for pattern in injection_patterns:
        if re.search(pattern, text, re.IGNORECASE):
            logging.warning(f"[Sanitizer] Potential threat detected with pattern: '{pattern}'")
            raise ValueError(f"Input sanitization failed. Potential threat detected.")
    return text

# === Moderation Utility ===
def helper_moderate_content(text_to_moderate, client):
    """Uses the OpenAI Moderation API."""
    logging.info(f"Moderating content...")
    try:
        response = client.moderations.create(input=text_to_moderate)
        mod_result = response.results[0]
        
        report = {
            "flagged": mod_result.flagged,
            "categories": dict(mod_result.categories),
            "scores": dict(mod_result.category_scores)
        }
        
        if report["flagged"]:
            logging.warning(f"Content was FLAGGED by moderation API. Report: {report['categories']}")
        else:
            logging.info("Content PASSED moderation.")
            
        return report
            
    except Exception as e:
        logging.error(f"An error occurred during content moderation: {e}")
        return {"flagged": True, "categories": {"error": str(e)}, "scores": {}}

logging.info("✅ Helper functions defined and upgraded (Pinecone Removed).")