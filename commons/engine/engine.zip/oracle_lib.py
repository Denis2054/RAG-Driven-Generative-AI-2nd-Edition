%%writefile oracle_lib.py
# oracle_lib.py
# The Oracle Connection Manager (Colab Secrets Edition)
# -------------------------------------------------------------------------
import oracledb
import os
import logging
from contextlib import contextmanager
from google.colab import userdata

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - [OracleLib] - %(levelname)s - %(message)s')

class OracleManager:
    _pool = None

    @classmethod
    def initialize(cls):
        """
        Initializes the Oracle Connection Pool using Colab Secrets.
        """
        if cls._pool is not None:
            return

        logging.info("Initializing Oracle Connection Manager...")

        try:
            # 1. Load Credentials from Colab Secrets
            user = userdata.get("ORACLE_USER")
            pwd = userdata.get("ORACLE_PASSWORD")
            dsn = userdata.get("ORACLE_DSN")
            wallet_pwd = userdata.get("ORACLE_WALLET_PASSWORD")
            
            # 2. Define Wallet Path (Assumes standard mount)
            # Make sure your wallet is unzipped at this location in Drive
            wallet_dir = "/content/drive/MyDrive/wallet_23ai" 
            
            if not os.path.exists(wallet_dir):
                logging.warning(f"⚠️ Wallet directory not found at {wallet_dir}. Check your Drive mount.")

            # 3. Create Connection Pool
            cls._pool = oracledb.create_pool(
                user=user,
                password=pwd,
                dsn=dsn,
                min=1,
                max=4,
                increment=1,
                wallet_location=wallet_dir,
                wallet_password=wallet_pwd
            )
            logging.info("✅ Oracle Connection Pool created successfully.")

        except Exception as e:
            logging.error(f"Failed to initialize Oracle Pool: {e}")
            raise e

    @classmethod
    @contextmanager
    def get_cursor(cls):
        """
        Context Manager to provide a database cursor from the pool.
        """
        if cls._pool is None:
            # Attempt auto-initialization
            try:
                cls.initialize()
            except Exception as e:
                raise RuntimeError("Oracle Pool is not initialized.") from e

        connection = None
        cursor = None
        try:
            connection = cls._pool.acquire()
            cursor = connection.cursor()
            yield cursor
            connection.commit()
        except Exception as e:
            if connection:
                connection.rollback()
            raise e
        finally:
            if cursor:
                cursor.close()
            if connection:
                cls._pool.release(connection)

    @classmethod
    def close(cls):
        """Closes the connection pool."""
        if cls._pool:
            cls._pool.close()
            cls._pool = None
            logging.info("Oracle Connection Pool closed.")